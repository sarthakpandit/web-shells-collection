/*
 * dreloc - demo and testprogram. 
 *
 * Idea based on Binreloc (http://autopackage.org/docs/binreloc/, Public domain),
 * code simpilfied and supporting more operating systems than only Linux...
 *
 * Example (and test-)application for dreloc */

#include "dreloc.h"
#include <stdio.h>

int main()
{
	printf("Exepath: 		%s\n", dreloc_find_exepath());
	printf("Prefix: 		%s\n", dreloc_find_prefix());
	printf("/bin-Path: 		%s\n", dreloc_find_bin_dir());
	printf("/sbin-Path: 		%s\n", dreloc_find_sbin_dir());
	printf("/etc-Path: 		%s\n", dreloc_find_etc_dir());
	printf("/share-Path: 		%s\n", dreloc_find_share_dir());
	printf("/lib-Path: 		%s\n", dreloc_find_lib_dir());
	printf("/libexec-Path: 		%s\n", dreloc_find_libexec_dir());
	printf("Applicationsharedir: 	%s\n", dreloc_find_applicationshare_dir("exampleapplication-1.0"));
	return 0;
}
